void rgb2ycbcr(int r, int g, int b, int * y, int * cb, int * cr);
void rgb2yuv(int r, int g, int b, int * y, int * cb, int * cr);
int rgb2gray(int r, int g, int b);
int test_code(void);
