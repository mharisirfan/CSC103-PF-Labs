#include<stdio.h>
#include"my_lib.h"


int main (void)
{

	printf("Program to test color space conversion\n\n");

	printf("Testing color space conversion code: \n\n");
	if(test_code() == 0)
	   printf("\n\n Conversion Successful! Well Done!!\n");
	else
	   printf("\n\nOops! Conversion failed!!!\n\n");

}

void rgb2ycbcr(int r, int g, int b, int * y, int * cb, int * cr)
{

}

